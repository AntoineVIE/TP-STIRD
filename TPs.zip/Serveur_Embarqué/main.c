#include "serveur.h"
#include <pthread.h>

int main(int argc, char *argv[]){
	struct api_tcp_ip tcp;
	serveur_TCPIP((void *)&tcp);
	return 0;
}