#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef void (*Fonction) (u_char param_len, const char* parametres,
u_char* rep_len, char* reponse, void * io_file);

struct Table_repartition
{
	char * commande; /* nom de la commande */
	Fonction pFonction; /* nom de la fonction à exécuter */
};

struct api_tcp_ip
 {
 int socket_p;
 int socket_s;
 struct sockaddr_in s_addr;
 struct sockaddr_in c_addr;
 socklen_t c_addr_len;
 socklen_t s_addr_len;
 unsigned int s_port;
 void (* protocole)(int socket);
 void * io_file;
 };

 void * serveur_TCPIP(void *);
void protocole (int socket);