#include "serveur.h"
#define SA struct sockaddr
#define DIM 256

struct Table_repartition table[] =
{
	//{"Start", OnStart},
	//{"Stop", OnStop},
	//{"Idle", OnIdle}//,
	//{"GetX", OnGetX},
	//{"SetX", OnSetX},
	//{"GetACC", OnGetACC}
};


void * serveur_TCPIP(void * input)
{

 int i = 1;
 struct api_tcp_ip * serveur = (struct api_tcp_ip *) input; //On initialise la structure
 serveur->protocole = (void *) protocole; // On ajoute le protocole
 //On initialise le serveur
 serveur->s_addr.sin_family = AF_INET;
 serveur->s_addr.sin_port = htons(serveur->s_port = 1234);
 serveur->s_addr.sin_addr.s_addr = INADDR_ANY;
 printf("Server initialized: %d \n",serveur->s_port);
 //On crée le socket principal, celui du serveur
 if((serveur -> socket_p = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1){
		 printf("Could not create socket");
		 exit(0);
	 }
	
 
 //On assigne l'adresse du serveur
 if (bind(serveur->socket_p, (SA*)&serveur->s_addr, sizeof(serveur->s_addr)) == SO_ERROR) { 
        printf("socket bind failed...\n"); 
        exit(0); 
    } 
 ;
 //Marque la socket qui sera utilisée pour accepter les demandes de connexions
 if ((listen(serveur->socket_p,3)) != 0) { 
        printf("Listen failed...\n"); 
        exit(0); 
    }
 else{
        printf("Waiting connections..\n"); 
	}	
 while(1)
 {
 //On attend les connexions 
 serveur->c_addr_len = sizeof(serveur->c_addr);
 serveur->socket_s = accept(serveur->socket_p, (SA*)&serveur->c_addr,&serveur->c_addr_len);
 //On manage les options du socket client
 setsockopt(serveur->socket_s, IPPROTO_TCP, 0x0001, (char*) &i,
 sizeof(i)); /* time out = inf */
 signal(SIGPIPE, SIG_IGN); /* Signal broken Pipe = off */
 
   
 printf("Client connecté (%d). IP: %s \n",serveur->s_port,
 inet_ntoa(serveur->c_addr.sin_addr));
 serveur->protocole(serveur->socket_s);
 //On reçoit les données et on les traite
 
 
 //On ferme le socket client
 shutdown(serveur->socket_s,2);
 close(serveur->socket_s);
 printf(" Client déconnecté\n");
 }
 //On ferme le socket serveur
  shutdown(serveur->socket_p,2);
 close(serveur->socket_p);
}

void protocole (int socket)
{
	
	int n_com;
	char reply[DIM] = ""; //Ceci contiendra la trame de commande envoyée apr le client
	char commande[26] = "";
	char len_commande[5] = "";
	char len_parametre[5] = "";
	char parametre[26] = "";
	if(recv(socket,reply, sizeof(reply),0)<0){
		puts("Recv failed\n");
        //return 1;
		exit(0);
	}
	else{
		//On copie ce qui nous intéresse 
		memcpy(&len_commande, &reply[0x00], 0x04);
		printf("%s\n", len_commande);
		//On convertit en int
		int len_c = strtol(len_commande, NULL, 16);
		//On copie ce qui nous intéresse
		memcpy(&commande, &reply[len_c-1], len_c);
		printf("%s\n", commande);
		//On cherche à savoir s'il y'a des paramètres à la fonction
		if (reply[2*len_c-1] != '\0') {
			//On fait comme précédemment
			memcpy(&len_parametre, &reply[2*len_c-1], 0x04);
			printf("%s\n", len_parametre);
			
			int len_p = strtol(len_parametre, NULL, 16);

			memcpy(&parametre, &reply[2*len_c+len_p-1], len_p);
			printf("%s\n", parametre);
		}
	}
			
	if (strcmp(commande, "START") == 0) {
		n_com = 0;
		printf("La commande est : %s\n", commande);
	} 
	else if (strcmp(commande, "STOP") == 0) {
		n_com = 1;
		printf("La commande est : %s\n", commande);
	} 
	else if (strcmp(commande, "IDLE") == 0) {
		n_com = 2;
		printf("La commande est : %s\n", commande);
	}
	// On ne peut pas utiliser ceci car les fonctions qu'on devrait appeler ne sont pas codée.
	//table[n_com].pFonction(slide_status,param_len_int,parametres,&rep_len,&reponse,io_file);
	if(send(socket, commande, sizeof(commande),0) < 0){
		puts("Send failed\n");
        //return 1;
		exit(0);
	}
	else{
		printf("Data send\n");
	}
}	

