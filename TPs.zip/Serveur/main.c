#include "serveur.h"

int main(int argc, char *argv[]){
	char* message = "Bonjour client";
	char reply;
	struct tcp_ip tcp;
	Init(&tcp);
	Start(&tcp);
	//getchar();
	Set(&tcp, message, strlen(message));
	Get(&tcp, &reply, strlen(message));
	
	Stop(&tcp);
	//printf("Fin");
	return 0;
}
