#include "serveur.h"

#define SA struct sockaddr

//Pour les commentaires cf. serveurembarqué

int Init(struct tcp_ip *tcp){
    if(WSAStartup(MAKEWORD(2,2), &tcp->WSAData)!=0){
		printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
	}
    tcp->ServeurAddr.sin_family = AF_INET;
    tcp->ServeurAddr.sin_port = htons(tcp->ServeurPort = 1234);
    tcp->ServeurAddr.sin_addr.s_addr = INADDR_ANY;
	printf("Server initialized\n");
}

int Start(struct tcp_ip *tcp){
	 if((tcp -> p = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET){
		 printf("Could not create socket : %d" , WSAGetLastError());
		 exit(0);
	 }
	 if ((bind(tcp->p, (SA*)&tcp->ServeurAddr, sizeof(tcp->ServeurAddr))) == SOCKET_ERROR) { 
        printf("socket bind failed...\n"); 
        exit(0); 
    } 
    else{
        printf("Socket successfully binded..\n"); 
	}
	if ((listen(tcp->p, 3)) != 0) { 
        printf("Listen failed...\n"); 
        exit(0); 
    } 
    else{
        printf("Waiting connections..\n"); 
	}
	int len = sizeof(tcp->ClientAddr);
	tcp-> s = accept(tcp->p, (SA*)&tcp->ClientAddr,&len); 
	if (tcp->s == INVALID_SOCKET){
		printf("accept failed with error code : %d" , WSAGetLastError());
	}
	puts("Connection accepted");
} 

int Stop(struct tcp_ip *tcp){
	WSACleanup();
}

int Set(struct tcp_ip* tcp, char* message, int dim){
	if(send(tcp->s, message, dim,0) < 0){
		puts("Send failed\n");
        return 1;
	}
	else{
		printf("Data send\n");
	}
}

int Get(struct tcp_ip* tcp, char* message, int dim){
	if(recv(tcp->s,message, dim,0)<0){
		puts("Recv failed\n");
        return 1;
	}
	else{
		puts(message);
	}
}


