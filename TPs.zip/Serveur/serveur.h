#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct tcp_ip{
    SOCKET s;
    SOCKET p;
    SOCKADDR_IN ServeurAddr;
    SOCKADDR_IN ClientAddr;
    WSADATA WSAData;
    int ServeurPort;
    const char* ServeurIp;
};

//Initialisation client
int Init(struct tcp_ip *);
int Start(struct tcp_ip*);
int Stop(struct tcp_ip*);
int Set(struct tcp_ip*, char*, int);
int Get(struct tcp_ip*, char*, int);


