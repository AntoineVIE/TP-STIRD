#include "client.h"

#define SA struct sockaddr

int Init(struct tcp_ip *tcp){
	//Initialisation du client
    WSAStartup(MAKEWORD(2,2), &tcp->WSAData);
    tcp->ServeurAddr.sin_family = AF_INET;
    tcp->ServeurAddr.sin_port = htons(tcp->ServeurPort = 1234);
    tcp->ServeurAddr.sin_addr.s_addr = inet_addr(tcp->ServeurIp = "192.168.1.94");
}

int Start(struct tcp_ip *tcp){
	//On cré le socket selon nos besoins
    tcp->s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (tcp->s == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
	else{
        printf("Socket successfully created..\n");
	}
	//On se connecte au serveur
	if (connect(tcp->s, (SA*)&tcp->ServeurAddr, sizeof(tcp->ServeurAddr)) != 0) {
        printf("connection with the server failed...\n");
        exit(0);
    }
    else{
        printf("connected to the server..\n");
    }
}

int Stop(struct tcp_ip *tcp){
	//On ferme le socket
	closesocket(tcp->s);
	WSACleanup();
}

int Set(struct tcp_ip* tcp, char* message, int dim){
	//On envoie une chaîne de caractère
	if(send(tcp->s, message, dim,0) < 0){
		puts("Send failed\n");
        return 1;
	}
	else{
		printf("Data send\n");
	}
}
int Get(struct tcp_ip* tcp, char* message, int dim){
	//On reçoit une chaîne de caractère
	if(recv(tcp->s,message, dim,0)<0){
		puts("Recv failed\n");
        return 1;
	}
	else{
		puts(message);
	}
}