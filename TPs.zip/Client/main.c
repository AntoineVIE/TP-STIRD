#include "client.h"
#include <string.h>
int main(int argc, char *argv[]){
	char* message = "0x05START";
	char* message2 = "0x040.05";
	size_t len = strlen(message2);

	char buffer[256];
	strcat(strcpy(buffer,message),message2);
	int i = 0x05;
	printf("%d",i);
	char reply;
	struct tcp_ip tcp;
	Init(&tcp);
	Start(&tcp);

	if(send(tcp.s, buffer, strlen(buffer),0) < 0){
		puts("Send failed\n");
        return 1;
	}
	else{
		printf("Data send\n");
	}
	//Set(&tcp, &message, strlen(message));
	Get(&tcp, &reply, sizeof(&reply));
	Stop(&tcp);
	//printf("Fin");
	return 0;
}
